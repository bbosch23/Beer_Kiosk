var mysql = require('mysql');

var con = mysql.createConnection({
    host: '127.0.0.1',
    port: '3306',
    user: 'root',
    password: 'password',
    database: 'drinks'
});

//COMMAND TO LOAD FILE INTO DB
//LOAD DATA LOCAL INFILE '/zBeer/Book1.csv' INTO TABLE list FIELDS TERMINATED BY ',' 
//LINES TERMINATED BY '\r\n' IGNORE 1 ROWS (name, brand, pack_count, ALCP, description, type) 

//currently set to display database
 con.connect(function(err) {
  if (err) throw err;
  con.query("SELECT * FROM list", function (err, result, fields) {
    if (err) throw err;
    console.log(result);
  });
});