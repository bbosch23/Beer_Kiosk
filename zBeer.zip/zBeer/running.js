
  const http = require("http");
  const PORT = 8080;
  
  
  const requestHandler = (req, res) => {
  	res.end("Hello from AWS Cloud9!")
  }
  
  const server = http.createServer(requestHandler);
  
  server.listen(PORT, (err) => {
  	if (err) {
  		console.log("Error occurred", err) ;
  	}
  	console.log(`Server is listening on ${PORT}`);
  })
  const csv = require('csv-parser');
  const fs = require('fs');



function open()
{
  //opens files
  var i =0;
  var array = fs.readFileSync('Book1.csv').toString().split("\n");
  var drinkload = new Array();
  
  //logger
  /**for(i in array) {
      console.log(array[i]);
  }**/
  
  let Drink = require('./Drink.js');
  //takes line and splits into array to store as data object
  i=0;
  var holder;
  for(i in array)
  {
    holder=array[i];
    holder=holder.split(',');
    drinkload.push(new Drink(holder[0],holder[1],holder[2],holder[3],holder[4],holder[5])); //name,brand,packCount,Alc,des,type
  }
  return drinkload;
  
  /** logger
  var x=x
  for(x in drinkload)
  {
    console.log(drinkload[x])
  }
  **/
  
  //logger
  /**
  fs.createReadStream('Book1.csv')
    .pipe(csv())
    .on('data', (row) => {
      console.log(row);
    })
    .on('end', () => {
      console.log('CSV file successfully processed');
    });
    **/
    //storing array
    
}
  //database testing
//NOTW WORKING.
