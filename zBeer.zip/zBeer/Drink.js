// JavaScript File
//drink object file
class Drink{
    constructor(name,brand,packCount,Alc,des,type)
    {
        this.name=name;
        this.brand=brand;
        this.packCount=packCount
        this.des=des;
        this.type=type;
    }
//getters
    get Name()
    {
        return this.name;
    }
    get Brand()
    {
        return this.brand;
    }
    get PackCount()
    {
       return this.packCount;
    }
    get Alc()
    {
       return this.Alc;
    }
    get Des()
    {
        return this.des;
    }
    get Type()
    {
        return this.type;
    }

//setters
    set Name(inbound)
    {
        this.name = inbound;
    }
    set Type(inbound)
    {
        this.type=inbound;
    }
    set Brand(inbound)
    {
        this.brand=inbound;
    }
    set Des(inbound)
    {
        this.des=inbound;
    }
}
module.exports=Drink;